# 冷极暖站 W02 R04 Reviewed
当前修订集：CAD/DWG与DXF共9张，图纸PDF9页A3，真实SKP、SketchUp原生导出的DAE、三种同源GLB、统一参数及简要验收记录。打开03_SketchUp/SKP中的R04模型；图纸见02_Drawings_PDF。A03/A04 CAD图签均已修正为R04；A04面板/基层描述及A08尺寸、连接、比例标注已局部更新。其余图纸与SKP/DAE/GLB几何保留。

保留原建筑方案与墙厚。新增A08仅表达本次相关排水、锁止防夹、坡道端部及供暖停电技术内容。所有几何尺寸均为教学值。实际验证和未验证项见07_QC_Report/GENHE_W02_R04_Review_Summary.md。
