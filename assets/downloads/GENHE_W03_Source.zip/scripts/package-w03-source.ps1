$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$distRoot = Join-Path $projectRoot 'dist'
$downloadRoot = Join-Path $distRoot 'assets\downloads'
$outputPath = Join-Path $downloadRoot 'GENHE_W03_Source.zip'
$tempRoot = (Resolve-Path $env:TEMP).Path.TrimEnd('\') + '\'
$stagePath = Join-Path $tempRoot ('genhe-w03-source-' + [guid]::NewGuid().ToString('N'))

if (-not (Test-Path -LiteralPath $downloadRoot)) {
  New-Item -ItemType Directory -Force -Path $downloadRoot | Out-Null
}
if (-not $outputPath.StartsWith($projectRoot, [StringComparison]::OrdinalIgnoreCase)) {
  throw 'Output path escaped the project directory.'
}
if (-not $stagePath.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase)) {
  throw 'Staging path escaped the system temp directory.'
}

New-Item -ItemType Directory -Path $stagePath | Out-Null
try {
  $excludedNames = @('.git', '.openai', 'node_modules', '.worktrees')
  Get-ChildItem -LiteralPath $projectRoot -File -Recurse -Force | ForEach-Object {
    $relative = $_.FullName.Substring($projectRoot.Length).TrimStart('\', '/')
    $segments = $relative -split '[\\/]'
    if ($segments | Where-Object { $excludedNames -contains $_ }) { return }
    if ($relative -eq 'dist\assets\assignment-manifest.json') { return }
    if ($relative -eq 'dist\assets\downloads\GENHE_W03_Source.zip') { return }
    if ($relative -eq 'dist\assets\downloads\第一周作业.zip') { return }
    if ($relative -eq 'dist\assets\downloads\第二周第三周.zip') { return }
    $destination = Join-Path $stagePath $relative
    $parent = Split-Path -Parent $destination
    if (-not (Test-Path -LiteralPath $parent)) {
      New-Item -ItemType Directory -Force -Path $parent | Out-Null
    }
    Copy-Item -LiteralPath $_.FullName -Destination $destination
  }

  $readme = @'
# GENHE WARM STATION · W03 Source Package

This package contains the editable W03 website source and its R04-aligned web model assets.

- Start locally with `打开网站.cmd` or `node serve.mjs`.
- W01 and W02 original submissions are available as separate downloads on the published assignment archive page.
- `dist/assets/assignment-manifest.json` is generated per release and omitted here because it records this package's checksum.
- `VERSION_LOCK.json` records W01 REV2 / W02 R04 model identity. `tests.mjs` and `tests/assignment-archive.mjs` provide local checks.
- CAD, SKP, DAE and source model files are not changed by the W03 website source package.

The website simulations are teaching scenarios and do not replace structural, thermal, snow-load, accessibility or equipment engineering checks.
'@
  Set-Content -LiteralPath (Join-Path $stagePath 'SOURCE_PACKAGE_README.md') -Value $readme -Encoding UTF8
  if (Test-Path -LiteralPath $outputPath) {
    Remove-Item -LiteralPath $outputPath -Force
  }
  Compress-Archive -Path (Join-Path $stagePath '*') -DestinationPath $outputPath -CompressionLevel Optimal
  $sha256 = [System.Security.Cryptography.SHA256]::Create()
  $stream = [System.IO.File]::OpenRead($outputPath)
  try {
    $hash = [BitConverter]::ToString($sha256.ComputeHash($stream)).Replace('-', '')
  }
  finally {
    $stream.Dispose()
    $sha256.Dispose()
  }
  [PSCustomObject]@{ Path = $outputPath; Hash = $hash }
}
finally {
  $resolvedStage = (Resolve-Path -LiteralPath $stagePath).Path
  if (-not $resolvedStage.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Refusing to clean a staging path outside the system temp directory.'
  }
  Remove-Item -LiteralPath $resolvedStage -Recurse -Force
}
