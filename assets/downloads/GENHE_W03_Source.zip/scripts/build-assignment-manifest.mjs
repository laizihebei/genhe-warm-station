import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
const fileHash = (relativePath) => crypto.createHash('sha256').update(fs.readFileSync(path.join(dist, relativePath))).digest('hex');
const describe = (relativePath, label) => ({ path: relativePath, label, sha256: fileHash(relativePath) });

const sourceDirectoryMissingNativeLogs = [
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A00_reopen.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A00_save.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A01_reopen.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A01_save.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A02_reopen.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A02_save.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A03_reopen.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A03_save.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A04_reopen.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A04_save.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A05_reopen.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A05_save.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A06_reopen.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A06_save.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A07_reopen.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A07_save.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A08_reopen.log',
  '07_QC_Report/Native_AutoCAD/GENHE_W02_R04_A08_save.log',
];

const weeks = [
  {
    id: 'W01',
    version: 'REV2',
    title: '研究场地与使用问题',
    downloads: [describe('assets/downloads/第一周作业.zip', '第一周原始作业包（PDF、DOCX、说明文件）')],
  },
  {
    id: 'W02',
    version: 'R04',
    title: '建筑图纸与可编辑模型',
    downloads: [
      describe('assets/downloads/第二周第三周.zip', '第二、三周原始交付包'),
      describe('assets/drawings.pdf', '建筑图纸 PDF'),
      describe('assets/building.skp', 'SketchUp 可编辑模型'),
      describe('assets/building.glb', '同源三维交换模型'),
      describe('assets/parameters.json', '建筑参数'),
    ],
  },
  {
    id: 'W03',
    version: 'INTERACTIVE',
    title: '环境响应网站',
    links: [{ path: 'index.html', label: '打开 W03 交互网站' }],
    downloads: [describe('assets/downloads/GENHE_W03_Source.zip', 'W03 网站源码包')],
  },
];

const manifest = {
  title: '冷极暖站 W01—W03 课程作业归档',
  generatedFrom: 'GENHE_W03 source checkout',
  weeks,
  w02: {
    integrity: {
      originalR04ExtractedFileCount: 91,
      originalR04ExtractedMissingLockedFileCount: sourceDirectoryMissingNativeLogs.length,
      originalR04ExtractedMissingNativeLogs: sourceDirectoryMissingNativeLogs,
      lockManifestExpectedFileCount: 105,
      originalArchiveRegularFileCount: 112,
      originalArchiveLockedFileCount: 105,
      originalArchiveMissingLockedFileCount: 0,
      originalArchiveSupplementalFileCount: 7,
      originalArchiveMissingNativeLogs: [],
      claimsNativeApplicationValidation: false,
      note: '原始R04解压目录（复核副本除外）少18份AutoCAD日志，已从原始压缩包恢复到复核副本；原始压缩包包含清单锁定的105项且哈希匹配，另含7项辅助文件。日志只作为随包记录，不代表本轮重新执行了AutoCAD原生验证。',
    },
  },
  studyAssessment: {
    label: '课程自评，不是教师评分标准',
    maxPoints: 100,
    rubric: {
      buffer: 30,
      circulationAndAccessibility: 25,
      winterDaylight: 20,
      maintenance: 25,
    },
  },
};

fs.writeFileSync(path.join(dist, 'assets', 'assignment-manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
console.log(`Wrote assignment manifest with ${weeks.length} weeks, ${sourceDirectoryMissingNativeLogs.length} missing source-directory logs, and checksums for ${weeks.reduce((sum, week) => sum + week.downloads.length, 0)} downloads.`);
