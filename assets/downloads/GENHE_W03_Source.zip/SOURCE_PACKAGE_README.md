# GENHE WARM STATION · W03 Source Package

This package contains the editable W03 website source and its R04-aligned web model assets.

- Start locally with `打开网站.cmd` or `node serve.mjs`.
- W01 and W02 original submissions are available as separate downloads on the published assignment archive page.
- `dist/assets/assignment-manifest.json` is generated per release and omitted here because it records this package's checksum.
- `VERSION_LOCK.json` records W01 REV2 / W02 R04 model identity. `tests.mjs` and `tests/assignment-archive.mjs` provide local checks.
- CAD, SKP, DAE and source model files are not changed by the W03 website source package.

The website simulations are teaching scenarios and do not replace structural, thermal, snow-load, accessibility or equipment engineering checks.
