import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { assignmentPlans } from '../dist/assignment-studies.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../dist');
const readJson = (relativePath) => JSON.parse(fs.readFileSync(path.join(root, relativePath), 'utf8'));
const hash = (filePath) => crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');

const page = fs.readFileSync(path.join(root, 'assignments.html'), 'utf8');
assert.match(page, /W01 REV2/);
assert.match(page, /W02 R04/);
assert.match(page, /W03/);
assert.match(page, /study-only/);
assert.match(page, /原始R04解压目录（复核副本除外）有 91 个文件/);
assert.match(page, /原始压缩包共 112 个文件/);
assert.doesNotMatch(page, /未在目录或压缩包中找到/);

const archive = readJson('assets/assignment-manifest.json');
assert.deepEqual(archive.weeks.map((week) => week.id), ['W01', 'W02', 'W03']);
assert.equal(Object.values(archive.studyAssessment.rubric).reduce((sum, score) => sum + score, 0), 100);
for (const week of archive.weeks) {
  for (const file of week.downloads) {
    const localPath = path.join(root, file.path);
    assert.ok(fs.existsSync(localPath), `${file.path} must be included in the site archive`);
    assert.equal(hash(localPath), file.sha256, `${file.path} must match its recorded checksum`);
  }
}
assert.equal(archive.w02.integrity.lockManifestExpectedFileCount, 105);
assert.equal(archive.w02.integrity.originalR04ExtractedFileCount, 91);
assert.equal(archive.w02.integrity.originalR04ExtractedMissingLockedFileCount, 18);
assert.equal(archive.w02.integrity.originalR04ExtractedMissingNativeLogs.length, 18);
assert.equal(archive.w02.integrity.originalArchiveRegularFileCount, 112);
assert.equal(archive.w02.integrity.originalArchiveLockedFileCount, 105);
assert.equal(archive.w02.integrity.originalArchiveMissingLockedFileCount, 0);
assert.equal(archive.w02.integrity.originalArchiveSupplementalFileCount, 7);
assert.deepEqual(archive.w02.integrity.originalArchiveMissingNativeLogs, []);
assert.match(archive.w02.integrity.note, /原始压缩包包含清单锁定的105项且哈希匹配/);
assert.equal(archive.w02.integrity.claimsNativeApplicationValidation, false);

const version = readJson('assets/version.json');
assert.equal(version.parameters_sha256, hash(path.join(root, 'assets/parameters.json')));
assert.ok(fs.readFileSync(path.join(root, 'app.js'), 'utf8').includes('version.parameters_sha256'), 'the viewer must verify the R04 parameter file before parsing it');
const sourceLock = JSON.parse(fs.readFileSync(path.join(root, '../VERSION_LOCK.json'), 'utf8'));
const sourceParameters = sourceLock.source_files.find((file) => file.path === '06_Project_Parameters/GENHE_W02_R04_Parameters.json');
const sourceModel = sourceLock.source_files.find((file) => file.path === '04_Web_Model/GLB/GENHE_W02_R04_Interactive.glb');
assert.equal(sourceLock.W01, 'REV2');
assert.equal(sourceLock.W02, 'R04');
assert.equal(version.parameters_sha256, sourceParameters.sha256, 'site parameters must match the R04 version lock');
assert.equal(version.model_sha256, sourceModel.sha256, 'site GLB must match the R04 version lock');

assert.equal(assignmentPlans.length, 4);
for (const plan of assignmentPlans) {
  assert.equal(plan.studyOnly, true, `${plan.id} must remain a comparative study`);
  assert.equal(plan.modifiesR04, false, `${plan.id} must not claim to modify R04`);
  assert.ok(plan.partitionPaths.length, `${plan.id} needs a distinct schematic partition layout`);
  assert.deepEqual(Object.keys(plan.responses).sort(), ['cold', 'snow', 'sun']);
  for (const response of Object.values(plan.responses)) {
    assert.ok(response.before && response.after, `${plan.id} needs a before/after environmental comparison`);
  }
  const totalScore = Object.values(plan.scores).reduce((sum, score) => sum + score, 0);
  assert.ok(totalScore > 0 && totalScore <= 100, `${plan.id} self-assessment must be out of 100`);
}
assert.equal(new Set(assignmentPlans.map((plan) => plan.partitionPaths.join('|'))).size, 4, 'the four plan studies must show distinct spatial layouts');

console.log('PASS: W01/W02/W03 archive links and hashes, R04 discrepancy disclosure, four study-only environmental comparisons and 100-point self-assessments');
