﻿$taskRoot=$PSScriptRoot
$taskNode=(Get-Command node -ErrorAction SilentlyContinue).Source
if(-not $taskNode){$taskNode='C:\Users\24610\Node\node.exe'}
if(-not(Test-Path -LiteralPath $taskNode)){Write-Host '本机未找到Node，请安装Node后重试。';Read-Host;exit 1}
$taskReady=$false
try{$taskResponse=Invoke-WebRequest 'http://127.0.0.1:4173/assets/version.json' -TimeoutSec 2;$taskReady=$taskResponse.StatusCode -eq 200}catch{}
if(-not $taskReady){Start-Process -FilePath $taskNode -ArgumentList @('serve.mjs') -WorkingDirectory $taskRoot -WindowStyle Hidden;Start-Sleep -Milliseconds 900}
Start-Process 'http://127.0.0.1:4173'
