GENHE W01 REV2 finalized research package - 2026-10-13
1) Site analysis PDF (3 A3 sheets)
2) Project brief DOCX (editable)
3) Project brief PDF (4 A4 pages)
This package supersedes previous W01 versions. Keep historical originals archived.
